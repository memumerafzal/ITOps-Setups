# RDPWrap + win 10 privacy
Since so many people still use / find this, I've gone ahead and updated it, @sebaxakerhtc has streamlined the process.<br>
This repo is using Github actions, watching [sebaxakerhtc's](https://github.com/sebaxakerhtc/rdpwrap/) modified version of RDPWrap.<br>
Included is win10privacy to block windows updates.<br>
UNINSTALL YOUR CURRENT RDPWRAP IF IT IS INSTALLED, REBOOT THE MACHINE BEFORE STARTING THIS.<br>
For those that found this via the youtube video, the branch you see in video can be found [here](https://github.com/SobieskiCodes/RDPWrap/tree/youtube_branch).

## Setup


```css
Disable your antivirus software
Run Installer or Installer Black
Add exclusion for "C:\Program Files\RDP Wrapper" folder
Right-click W10Privacy.exe and choose Run as administrator from the context menu. Choose to make a system restore point. It’s also worth making a full system backup (just in case).
Go to Extras > Windows Updates to manage the options. There are six different check boxes.
Check the first five options
Click Set changed settings
Enable your antivirus software
Enjoy!
```

## Disclaimer
I took no part in either of these tools.
The original RDPWrap can be found [here](https://github.com/stascorp/rdpwrap)<br>
The automated custom RDPWrap used here can be found on [sebaxakerhtc's](https://github.com/sebaxakerhtc/) profile.<br>
And the original win10privacy can be found [here](https://www.winprivacy.de/english-home/)<br>
If this works for you, please consider donating to the authors as they made this possible.<br>

